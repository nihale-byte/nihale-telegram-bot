import os
import logging
import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.types import InputFile

TOKEN = os.getenv("BOT_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID", "@nihale_wave")

bot = Bot(token=TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()

post_queue = [
    {"text": "🌌 Nihale is the wave beyond perception.", "image": "media/image1.jpg"},
    {"text": "🌀 Dissolve boundaries. Reimagine reality.", "image": "media/image2.jpg"},
    {"text": "✨ You are already part of us.", "image": "media/image3.jpg"},
]

@dp.startup()
async def on_startup(bot: Bot):
    for post in post_queue:
        try:
            if "image" in post:
                photo = InputFile(post["image"])
                await bot.send_photo(chat_id=CHANNEL_ID, photo=photo, caption=post["text"])
            else:
                await bot.send_message(chat_id=CHANNEL_ID, text=post["text"])
            await asyncio.sleep(3 * 60 * 60)  # 3 часа между постами
        except Exception as e:
            logging.error(f"Error posting to channel: {e}")

if __name__ == "__main__":
    import asyncio
    from aiogram import Router
    dp.include_router(Router())
    asyncio.run(dp.start_polling(bot))
